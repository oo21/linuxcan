var group__kvdiag__diagnostics =
[
    [ "kvDiagAttachAnalyzer", "group__kvdiag__diagnostics.html#ga76d09ccb89cf756d954144582f730330", null ],
    [ "kvDiagCalculateBitrate", "group__kvdiag__diagnostics.html#gabc77cf695c7fb518263d32539a3aec9e", null ],
    [ "kvDiagCalculateClockOffset", "group__kvdiag__diagnostics.html#ga243548139dcbb64ff273648dd0c370dd", null ],
    [ "kvDiagDetachAnalyzer", "group__kvdiag__diagnostics.html#ga61263295b3feaad95c257eef05a9579b", null ],
    [ "kvDiagGetAnalyzerInfo", "group__kvdiag__diagnostics.html#ga348f389077d77b8fd4cf04ad53558aad", null ],
    [ "kvDiagGetNumberOfAnalyzers", "group__kvdiag__diagnostics.html#ga926f63f2ccb0b56ff4917151ab5e27fe", null ],
    [ "kvDiagReadSample", "group__kvdiag__diagnostics.html#ga43a268ee89c38c3ac496d20f35a48105", null ],
    [ "kvDiagReadSampleWait", "group__kvdiag__diagnostics.html#gaab9b2bc0856a7200d1f76533092eb023", null ],
    [ "kvDiagResetBitrateCalculation", "group__kvdiag__diagnostics.html#ga65bbdc1e8c8bf4affc8ba2041d72ff1a", null ],
    [ "kvDiagResetClockOffsetCalculation", "group__kvdiag__diagnostics.html#ga1708e589eb731c11c82a621b2a070d1d", null ],
    [ "kvDiagSetProgram", "group__kvdiag__diagnostics.html#gad615ea3768542e4d48f10d0dca4ef46d", null ],
    [ "kvDiagStart", "group__kvdiag__diagnostics.html#ga9cb62a80b9ffe4ea80b22acfb49bd3a4", null ],
    [ "kvDiagStop", "group__kvdiag__diagnostics.html#ga685c95a3e168601a28e680d9c820dd8a", null ]
];