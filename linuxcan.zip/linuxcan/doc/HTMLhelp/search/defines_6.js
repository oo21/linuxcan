var searchData=
[
  ['trigvar_5ftype_5fdisk_5ffull',['TRIGVAR_TYPE_DISK_FULL',['../kvmlib_8h.html#a94460ad7c11dcd147dd48b79a3bf2630',1,'kvmlib.h']]],
  ['trigvar_5ftype_5fexternal',['TRIGVAR_TYPE_EXTERNAL',['../kvmlib_8h.html#abdc8361fefcddc2ae8d776d387abef88',1,'kvmlib.h']]],
  ['trigvar_5ftype_5fmsg_5fdlc',['TRIGVAR_TYPE_MSG_DLC',['../kvmlib_8h.html#aa94bbfc2b0128d0e7a06a9b2bea60d76',1,'kvmlib.h']]],
  ['trigvar_5ftype_5fmsg_5fflag',['TRIGVAR_TYPE_MSG_FLAG',['../kvmlib_8h.html#a56ea9904a201416ff565cb41a87c15f8',1,'kvmlib.h']]],
  ['trigvar_5ftype_5fmsg_5fid',['TRIGVAR_TYPE_MSG_ID',['../kvmlib_8h.html#a2c5ad81e0956467a6e484ad26840c3c1',1,'kvmlib.h']]],
  ['trigvar_5ftype_5fsigval',['TRIGVAR_TYPE_SIGVAL',['../kvmlib_8h.html#a568820a44f8901e30da9a439359582d5',1,'kvmlib.h']]],
  ['trigvar_5ftype_5fstartup',['TRIGVAR_TYPE_STARTUP',['../kvmlib_8h.html#aa4abaae7eb27ff6620a41ff00b39ce1a',1,'kvmlib.h']]],
  ['trigvar_5ftype_5ftimer',['TRIGVAR_TYPE_TIMER',['../kvmlib_8h.html#a9f6e51d03e405b09495437187362c0c4',1,'kvmlib.h']]]
];
